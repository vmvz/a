module.exports = {
    'proxyHost': 'http://localhost:3000',
    'target': 'http://www.duckduckgo.com',
    'replace': [
    ],
    'excludedElement': [
    ],
    'bottom': '',
    'header': '',
    'externalDomains': [
        'apis.google.com',
        'www.gstatic.com',
        'ssl.gstatic.com',
    ],
    'custom': {
    }
};