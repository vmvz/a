port='3000'

while getopts 'p:' flag; do
  case "${flag}" in
    p) port="${OPTARG}" ;;
    *) echo "Unexpected option ${flag}" ;;
  esac
done

echo "Running on Port ${port}"

sudo PORT=$port docker-compose up --build